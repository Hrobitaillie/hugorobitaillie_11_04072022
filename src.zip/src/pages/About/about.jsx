
import Banner from 'components/Banner/banner'

let title = "";

function About() {
  return (
    <div className="content">
      <Banner title={title} />
    </div>
  )
}

export default About
